﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supermercado_Guanabara.Modelo
{
    public enum TipoArtigo
    {
        Hortifruti, Talho, Peixaria, Papelaria, Higiene, Outros
    }
}
